# -*- coding: utf-8 -*-

import empro.toolkit.adv as adv

def main():
	path=r"U:/AST2_wrk"
	lib=r"AST2_lib"
	subst=r"AST2_lib/FR4.subst"
	substlib=r"AST2_lib"
	substname=r"FR4"
	cell=r"Filter"
	view=r"layout"
	libS3D=r"simulation/AST2_lib/%Filter/_3%D%Viewer/proj_libS3D.xml"
	varDictionary={}
	exprDictionary={}
	adv.loadDesign(path=path, lib=lib, subst=subst, substlib=substlib, substname=substname, cell=cell, view=view, libS3D=libS3D, var_dict=varDictionary, expr_dict=exprDictionary)
